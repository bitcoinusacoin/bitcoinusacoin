Sample configuration files for:
```
SystemD: bitcoinusad.service
Upstart: bitcoinusad.conf
OpenRC:  bitcoinusad.openrc
         bitcoinusad.openrcconf
CentOS:  bitcoinusad.init
macOS:    org.bitcoinusa.bitcoinusad.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
